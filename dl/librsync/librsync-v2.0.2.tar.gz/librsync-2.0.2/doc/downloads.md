# Downloads {#page_downloads}

librsync's home is http://librsync.sourcefrog.net/ and built documentation
is available there.

Source and bug tracking is at https://github.com/librsync/librsync/.

Source tarballs and git tags are at
https://github.com/librsync/librsync/releases.
